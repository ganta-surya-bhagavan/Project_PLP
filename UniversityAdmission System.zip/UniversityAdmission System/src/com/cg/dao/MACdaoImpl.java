package com.cg.dao;

import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.LogIn;

public class MACdaoImpl implements MACdao {

	@Override
	public String verifyUser(LogIn login) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Applicant> getApplicantsByCourseId(int CourseId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sheduleInterview(List<Applicant> applicant) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateStatus(int applicationId) {
		// TODO Auto-generated method stub
		return null;
	}

}
