package com.cg.dao;

import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;

public class StacticDataBase {
	static List<Courses> courses;
	static List<Applicant> applicant;
	static List<LogIn> login;  
	static{
		courses.add(new Courses("MBA","It is for professionals","B.Tech",2,"MBA"));
		courses.add(new Courses("MBA","It is for professionals","B.Tech",2,"MBA"));
		courses.add(new Courses("MBA","It is for professionals","B.Tech",2,"MBA"));
	}
	static{
		login.add(new LogIn("surya","surya","MAC"));
		login.add(new LogIn("sudhanshu","sudhanshu","MAC"));
		login.add(new LogIn("prerak","prerak","admin"));
	}
	
}
