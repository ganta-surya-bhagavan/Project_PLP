package com.cg.dao;

import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;

public class AdmindaoImpl implements Admindao {

	@Override
	public String verifyUser(LogIn login) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addCourse(Courses course) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteCourse(String ProgramName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addSchedule(Schedule schedule) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteSchedule(String Scheduled_program_id) {
		// TODO Auto-generated method stub
		return null;
	}

}
