package com.cg.exception;

public class ValidateApplicant extends RuntimeException {

}
