package com.cg.UI;
import java.util.Scanner;

public class MainUI {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the type of user");
	}

}
